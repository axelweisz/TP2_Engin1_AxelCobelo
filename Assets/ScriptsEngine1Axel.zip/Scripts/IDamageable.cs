public interface IDamageable
{
    public void ReceiveDamage(EDamageType damageType);
}
